
import baileys from "@adiwajshing/baileys"
import axios from "axios"
import fetch from "node-fetch"
import fs from "fs"
import util from "util"
import cp from "child_process"
import module from "module"
import os from "os"
import cheerio from "cheerio"
import FormData from "form-data"
import * as fileType from "file-type"
import syntaxerror from "syntax-error"
import yts from "yt-search"
import * as bochil from "@bochilteam/scraper"
import Jimp from "jimp";
import chalk from "chalk";
import path from 'path'



export default async function(sock, msg) {
  try {
    if (!msg.message) return;
    let m = new functions.default(msg, sock, {});
    let type = Object.keys(msg.message)[0]
    let pushname = msg.pushName
    let body = msg.message?.conversation || msg.message?.imageMessage?.caption || msg.message?.videoMessage?.caption || msg.message?.extendedTextMessage?.text || msg.message?.listResponseMessage?.singleSelectReply?.selectedRowId || msg.message?.buttonsResponseMessage?.selectedButtonId || msg.message?.templateButtonReplyMessage?.selectedId || "";
    let args = body.trim().split(/ +/).slice(1)
    let q = args.join(" ")
    let isGroup = m.from.endsWith("@g.us")
    let command = body.replace(prefix, '').trim().split(/ +/).shift().toLowerCase()
    let isOwner = !!owner.find(o => o == m.sender)
    if (m.key.remoteJid === 'status@broadcast') return sock.readMessages([m.key])
              
    if (isGroup && !isOwner) return; // tambahkan kondisi ini untuk menghindari bot menjawab di grup jika bukan owner

    if (command) {
      console.log(chalk.green(`[ MESSAGE ]`)), console.log(chalk.red(`from ${pushname} text: ${body}`))
    }

    switch (command) {
case 'nowa':
  let regex = /x/g;
  if (!q) {
    await sock.reply(m.from, 'Input Number', msg);
    return;
  }
  if (!q.match(regex)) {
    await sock.reply(m.from, `Ex: ${usedPrefix + command} ${m.sender.split('@')[0]}x`, msg);
    return;
  }
  let random = q.match(regex).length,
      total = Math.pow(10, random),
      array = [];
  for (let i = 0; i < total; i++) {
    let list = [...i.toString().padStart(random, '0')];
    let result = q.replace(regex, () => list.shift()) + '@s.whatsapp.net';
    let v = await sock.onWhatsApp(result).then(v => (v[0] || {}));
    if (v.exists) {
      let info = await sock.fetchStatus(result).catch(_ => {});
      let dateStr = await functions.formatDate(info.setAt);
      array.push({ exists: true, jid: result, status: info.status || '', date: dateStr });
    } else {
      array.push({ exists: false, jid: result });
    }
  }
  let registered = array.filter(v => v.exists),
      unregistered = array.filter(v => !v.exists);
  let txt = '• Registered\n\n' + registered.map(v => `No: wa.me/${v.jid.split('@')[0]}\nBio: ${v.status}\nDate: ${v.date}`).join('\n\n') + '\n\n• Unregister\n\n' + unregistered.map(v => v.jid.split('@')[0]).join('\n');
  await sock.reply(m.from, txt, msg);
  break;



case 'menu':
const menu = `
*SelfBot*
[System management] 
-> Owner Only
• >/=>/$
• update
• upload
• getcase
• getfunction

[Tools]
• gdrive
• play
• sticker
• tiktok
• ttmp3
• ytmp3
• nowa
• audio`
sock.reply(m.from, menu, msg)
break

case ">":
case "=>":
if (!isOwner && !m.key.fromMe) return;
var er = new EvalError("Input Code!!")
if (!q) return sock.sendText(m.from, util.format(er), { quoted: msg })
var arg = command == ">" ? args.join(" ") : "return " + args.join(" ")
try {
var text = util.format(await eval(`(async()=>{ ${arg} })()`))
sock.sendText(m.from, text, { quoted: msg })
} catch(e) {
let _syntax = ""
let _err = util.format(e)
let err = syntaxerror(arg, "EvalError", {
allowReturnOutsideFunction: true,
allowAwaitOutsideFunction: true,
sourceType: "module"
})
if (err) _syntax = err + "\n\n"
sock.sendText(m.from, util.format(_syntax + _err), { quoted: msg })
}
break;

case "$": 
  if (!isOwner && !m.key.fromMe) return;
try {
cp.exec(args.join(" "), function(er, st) {
if (er) sock.sendText(m.from, util.format(er.toString().replace(/[\u001b\u009b][[()#;?]*(?:[0-9]{1,4}(?:;[0-9]{0,4})*)?[0-9A-ORZcf-nqry=><]/g, '')), { quoted: msg })
if (st) sock.sendText(m.from, util.format(st.toString().replace(/[\u001b\u009b][[()#;?]*(?:[0-9]{1,4}(?:;[0-9]{0,4})*)?[0-9A-ORZcf-nqry=><]/g, '')), { quoted: msg })
})
} catch (e) {
console.warn(e)
}
break;

case "update":
cp.exec('exit && node .')
break;

         case "getfunction":
          sock.sendText(m.from, functions[q]+''.trim(), { quoted: msg })
          break 
          
        case "upload":
        case "tourl":
          var url;
          try {
            url = await functions.telegra(m.quoted ? await m.quoted.download() : await m.download())
          } catch {
            url = await functions.anonfiles.getDownloadUrl(m.quoted ? await m.quoted.download() : await m.download())
          }
          sock.sendText(m.from, url, {
            quoted: msg
          })
          break;    

case "gdrive":
  if (!q && !/drive/.test(q)) if (!q) sock.sendText(m.from, "Masukan URL dengan benar !!", { quoted: msg })
  var  { downloaUrl, fileName, mimetype } = await functions.gdrive(q)
  sock.sendFile(m.from, downloadUrl, { quoted: msg, fileName, mimetype })
  break

case "jadianime":
  case "toanime":
    var url = await functions.jadianime(await m.quoted.download())
    if (!/http/.test(url)) sock.sendText(m.from, "Error! coba foto lain.", { quoted: msg })
    sock.sendFile(m.from, url, { quoted: msg, caption: "Crop sendiri ya!" })
    break

case "play":
case "ytmp3":
  if (!q) sock.sendText(m.from, "Masukan Judul Lagu !!", { quoted: msg })
 var res = await (await yts(q)).all[0]
var url = await (await bochil.youtubedlv2(res.url)).audio["128kbps"].download()
 try {
sock.sendFile(m.from, await sock.fetchBuffer(url), { mimetype: "audio/mpeg", fileName: res.title+".mp3", contextInfo: {
externalAdReply: { 
showAdAttribution: true,
renderLargerThumbnail: true,
thumbnail: await sock.fetchBuffer(res.thumbnail),
title: res.title,
body: res.description,
sourceUrl: res.url,
mediaUrl: res.url,
mediaType: 2
}

},  quoted: msg })
  } catch {
sock.sendText(m.from, q+ "  not defined", { quoted: msg })
  }
  break

case "s":
  case "swm":
    case "stiker":
      case "sticker":
        sock.sendFile(m.from, await functions.sticker(await m.quoted.download(), "Whatsapp Bot", "Deff"), { quoted: msg })
        break

case "video":
case "ytmp4":
  if (!q) sock.sendText(m.from, "Masukan Judul Lagu !!", { quoted: msg })
 var res = await (await yts(q)).all[0]
var url = await (await bochil.youtubedlv2(res.url)).video["480p"].download()
 try {
sock.sendFile(m.from, await sock.fetchBuffer(url), { contextInfo: {
externalAdReply: { 
showAdAttribution: true,
renderLargerThumbnail: false,
thumbnail: await sock.fetchBuffer(res.thumbnail),
title: res.title,
body: res.description,
sourceUrl: res.url
}
},  quoted: msg })
  } catch {
sock.sendText(m.from, q+ "  not defined", { quoted: msg })
  }
  break

case "addfilter": 
case "audio":
  if (!q)  sock.sendText(m.from, "Example: audio reverb", { quoted: msg })
try {
await sock.sendMessage(m.from, {
audio: await functions.audio.create(await m.quoted.download(), {
  [args[0]]: args [1]
}),
mimetype: "audio/mpeg",
ptt: true }, {
quoted: msg
})
} catch {
  sock.sendText(from, "Effect "+args [0]+" not defined", { quoted: msg })
}
break

case "ttmp3":
case "tiktokmp3":
  if (!q && !/tiktok.com/.test(body)) sock.sendText(m.from, "Masukan URL dengan benar!!", { quoted: msg })
  var { url } = await (await bochil.savefrom (q))[0].url[0]
  sock.sendFile(m.from, await functions.toAudio(await sock.fetchBuffer(url[0].url)), { mimetype: "audio/mpeg", quoted: msg })
  break;
  
case "getcase":
  if (!q)  sock.sendText(m.from, "Input Nama Case!!", { quoted: msg })
 var kontol = `case "${q}":` + await (await functions.baca("./index.js")).toString().split(`case "${q}":`)[1].split("break")[0] + "break;"
 sock.sendText(m.from, kontol, { quoted: msg})
 
case "read":
if (!msg.message[type]?.contextInfo?.quotedMessage) return;
var tipeQuot = Object.keys(msg.message[type].contextInfo.quotedMessage)[0]
if (tipeQuot == "viewOnceMessage") {
var anu = msg.message.extendedTextMessage.contextInfo.quotedMessage.viewOnceMessage.message
var tipe = Object.keys(anu)[0]
delete anu[tipe].viewOnce
var ah = {}
if (anu[tipe].caption) ah.caption = anu[tipe].caption
if (anu[tipe]?.contextInfo?.mentionedJid) {
ah.contextInfo = {}
ah.contextInfo.mentionedJid = anu[tipe]?.contextInfo?.mentionedJid || []
}
var dta = await baileys.downloadContentFromMessage(anu[tipe], tipe.split("M")[0])
sock.sendMessage(m.from, {
[tipe.split("M")[0]]: await functions.streamToBuff(dta),
...ah
}, {
quoted: msg
})
}
if (tipeQuot == "documentMessage") {
var text = (await m.quoted.download()).toString()
if (text.length >= 65000) text.slice(65000)
sock.reply(m.from, text, msg)
}
break;

  case "tiktok": 
    case "tt": 
  if (!q && !/tiktok.com/.test(body)) sock.sendText(m.from, "Masukan URL dengan benar!!", { quoted: msg })
  var { url } = await (await bochil.savefrom (q))[0].url[0]
  sock.sendFile(m.from, await sock.fetchBuffer(url), { quoted: msg })
  break;
                 
        default: 
                }
            } catch (e) {
                console.log(e)
            }
}


