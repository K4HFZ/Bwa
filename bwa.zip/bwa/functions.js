import baileys from "@adiwajshing/baileys";
import axios from "axios"
import fetch from "node-fetch"
import fs from "fs"
import hr from "human-readable"
import * as fileType from "file-type"
import cheerio from "cheerio"
import pn from "awesome-phonenumber"
import Jimp from "jimp"
import FormData from "form-data"
import md5 from "md5"
import requestlib from "request"
import crypto from "crypto"
import ff from "fluent-ffmpeg"
import webp from "node-webpmux"
import path from "path"
import util from "node:util"
import cp from "child_process"

let sock = {};
let store = {};

const __filename = path.resolve(import.meta.url.slice(7))
const __dirname = path.dirname(__filename)

function Message(msg, client, conn) {
    sock = client;
    store = conn;
    if (!msg?.message) return;
    let type = baileys.getContentType(msg.message)
    this.key = msg.key;
    this.from = this.key.remoteJid;
    this.chat = this.from
    this.fromMe = this.key.fromMe;
    this.id = this.key.id;
    this.isGroup = this.from.endsWith("@g.us");
    this.me = sock.type == "md" ? sock.user.id.split(":")[0] + baileys.S_WHATSAPP_NET : sock.state.legacy.user.id;
    this.sender = this.fromMe ? this.me : this.isGroup ? msg.key.participant : this.from;
    if (type == "conversation" || type == "extendedTextMessage") this.text = msg.message?.conversation || msg.message?.extendedTextMessage;
    this.type = type;
    this.isOwner = !!owner.find(v => v == this.sender);
    this.isBaileys = this.id.startsWith("BAE5") && this.id.length == 16;
    this.message = msg;
    if (this.message.message[type]?.contextInfo?.quotedMessage) this.quoted = new QuotedMessage(this, sock, store);
    this.pushname = msg.pushName;
    this.messageTimestamp = msg.messageTimestamp;
}
Message.prototype.toJSON = function() {
    let str = JSON.stringify({
        ...this
    });
    return JSON.parse(str);
};
Message.prototype.download = function() {
    return (async ({
        message,
        type
    }) => {
        if (type == "conversation" || type == "extendedTextMessage") return undefined;
        let stream = await baileys.downloadContentFromMessage(message.message[type], type.split("M")[0]);
        return await streamToBuff(stream);
    })(this);
};

function QuotedMessage(msg, sock, store) {
    let contextInfo = msg.message.message[msg.type].contextInfo;
    let type = baileys.getContentType(contextInfo.quotedMessage)
    this.key = {
        remoteJid: msg.from,
        fromMe: contextInfo.participant == msg.me,
        id: contextInfo.stanzaId,
        participant: contextInfo.participant
    };
    this.id = this.key.id;
    this.sender = this.key.participant;
    this.fromMe = this.key.fromMe;
    this.mentionedJid = contextInfo.mentionedJid;
    if (type == "conversation" || type == "extendedTextMessage") this.text = contextInfo.quotedMessage?.conversation || contextInfo.quotedMessage?.extendedTextMessage;
    this.type = type;
    this.isOwner = !!owner.find(v => v == this.sender);
    this.isBaileys = this.id.startsWith("BAE5") && this.id.length == 16;
    this.message = contextInfo.quotedMessage;
}

QuotedMessage.prototype.toJSON = function() {
    let str = JSON.stringify({
        ...this
    });
    return JSON.parse(str);
}

QuotedMessage.prototype.download = function() {
    return (async ({
        message,
        type
    }) => {
        if (type == "conversation" || type == "extendedTextMessage") return undefined;
        let stream = await baileys.downloadContentFromMessage(message[type], type.split("M")[0]);
        return await streamToBuff(stream);
    })(this);
};

QuotedMessage.prototype.delete = function() {
    return sock.sendMessage(this.key.remoteJid, {
        delete: {
            remoteJid: this.key.remoteJid,
            id: this.id,
            fromMe: this.fromMe,
            participant: this.sender
        }
    });
};

QuotedMessage.prototype.getQuotedObj = function() {
    return (async ({
        key,
        id
    }, sock, store) => {
        let res = await store.loadMessage(key.remoteJid, id);
        return new Message(res, sock, store);
    })(this, sock, store);
};
export function isUrl(url) {
    return /https?:\/\/(www\.)?[-a-zA-Z0-9@:%._+~#=]{1,256}\.[a-zA-Z0-9()]{1,6}\b([-a-zA-Z0-9()@:%_+.~#?&/=]*)/gi.test(url)
}
export async function streamToBuff(stream) {
    let buff = Buffer.alloc(0)
    for await (const chunk of stream) buff = Buffer.concat([buff, chunk])
    return buff
}
export async function formatDate(n, locale = 'id') {
	let d = new Date(n)
	return d.toLocaleDateString(locale, { timeZone: 'Asia/Jakarta' })
}
function Formarter() {
    this.util = util.format
    this.size = formatSize
    this.date = function(fmt) {
        let date = new Date(((fmt + "000") * 1) + (1000 * 60 * 60 * 7))
        let YYYY = date.getFullYear()
        let MM = date.getMonth() + 1
        let DD = date.getDate()
        let hh = date.getHours()
        let mm = date.getMinutes()
        let ss = date.getSeconds()

        return [YYYY, MM, DD].map(v => ("" + v).padStart(2, "0")).join("-") + ", " + [hh, mm, ss].map(v => ("" + v).padStart(2, "0")).join(":")
    }
    this.money = function(n, opt = "IDR") {
            return n.toLocaleString("id", {
                style: "currency",
                currency: opt
            })
        },
        this.number = function(n) {
            return n.toLocaleString("id")
        }
    this.clock = function clockString(ms) {
        let Y = Math.floor(ms / 31104000000);
        let M = Math.floor(ms / 2592000000) % 12;
        let D = Math.floor(ms / 86400000) % 30;
        let h = Math.floor(ms / 3600000) % 24;
        let m = Math.floor(ms / 60000) % 60;
        let s = Math.floor(ms / 1000) % 60;
        console.log({
            Y,
            M,
            D,
            ms,
            h,
            m,
            s
        });
        return Y.toString().padStart(2, 0) + "-" + M.toString().padStart(2, 0) + "-" + D.toString().padStart(2, 0) + ", " + [h, m, s].map(v => v.toString().padStart(2, 0)).join(":");
    }
    this.FtoC = function(f) {
        if (f.endsWith("°F")) return "" + Math.ceil(((f.replace(/[^0-9]/g, "") * 1) - 32) * 5 / 9) + "°C"
        else return f
    }
    this.json = function(j) {
        return JSON.stringify(j, null, 2)
    }
    this.bytes = function(bytes) {
        const sizes = ["B", "KB", "MB", "GB", "TB"]
        if (bytes == 0 || isNaN(bytes * 1)) return "0 B"
        const i = parseInt(Math.floor(Math.log(bytes) / Math.log(1024)))
        return (bytes / Math.pow(1024, i)) + " " + sizes[i]
    }
}
let formatSize = hr.sizeFormatter({
    std: 'JEDEC',
    decimalPlaces: 2,
    keepTrailingZeroes: false,
    render: (literal, symbol) => `${literal} ${symbol}B`
})
export function reSize(buffer, ukur1, ukur2) {
    return new Promise(async (resolve, reject) => {
        var baper = await Jimp.read(buffer);
        var ab = await baper.resize(ukur1, ukur2).getBufferAsync(Jimp.MIME_PNG)
        resolve(ab)
    })
}
export function hapus(path) {
    fs.unlinkSync(path)
    return path
}
export function baca(path) {
    return fs.readFileSync(path)
}
export function simpan(path, buff) {
    fs.writeFileSync(path, buff)
    return path
}

function anonFiles() {
    this.getDownloadUrl = async function(buff) {
        let {
            data
        } = await this.upload(buff)
        return await this.download(data.file.url.full)
    }
    this.upload = async function(buff) {
        var {
            ext
        } = await fileType.fileTypeFromBuffer(buff)
        var request = requestlib.defaults({
            headers: {
                'User-Agent': 'AnonFile-LIB Api Wrapper 1.0.1 by Jacub'
            }
        });
        return new Promise((resolve) => {
            var anonupreq = request.post(`https://api.anonfiles.com/upload`, (err, res, body) => {
                resolve(JSON.parse(body));
            });
            var form = anonupreq.form();
            form.append('file', fs.createReadStream(simpan(".cache/DEFF-BOT" + getRandom(ext), buff)))
        });
    }
    this.download = async function(url) {
        let $ = cheerio.load(await (await axios(url)).data)
        let res = $("#download-url").attr("href")
        return res
    }
}
export async function sticker(buffer, packname = "DEFF", author = "Daffa Yudhistira") {
    var imgType = await (await (await import("file-type")).fileTypeFromBuffer(buffer)).mime
    var buffer;
    if (imgType == "image/webp") buffer = await writeExifStc(buffer, {
        packname,
        author
    })
    if (imgType == "image/jpeg") buffer = await writeExifImg(buffer, {
        packname,
        author
    })
    if (imgType == "image/png") buffer = await writeExifImg(buffer, {
        packname,
        author
    })
    if (imgType == "video/mp4") buffer = await writeExifVid(buffer, {
        packname,
        author
    })
    return buffer
}

export async function telegra(buffer) {
    var ftp = await fileType.fileTypeFromBuffer(buffer)
    let file = Buffer.isBuffer(buffer) ? simpan(".cache/DEFF-BOT" + getRandom(ftp.ext), buffer) : buffer
    let form = new FormData
    form.append("file", fs.createReadStream(file), "kontol.jpg")
    let res = await (await fetch("https://telegra.ph/upload", {
        method: "POST",
        body: form
    })).json()
    return "https://telegra.ph" + res[0].src
}

export async function emoji_mix(em, oji) {
    return await (await axios(`https://tenor.googleapis.com/v2/featured?key=AIzaSyAyimkuYQYF_FXVALexPuGQctUWRURdCYQ&contentfilter=high&media_filter=g_transparent&component=proactive&collection=emoji_kitchen_v5&q=${encodeURIComponent(em)}_${encodeURIComponent(oji)}`)).data.results[0].url
}
export async function gdrive(url) {
    let id
    if (!(url && url.match(/drive\.google/i))) throw 'Invalid URL'
    id = (url.match(/\/?id=(.+)/i) || url.match(/\/d\/(.*?)\//))[1]
    if (!id) throw 'ID Not Found'
    let res = await fetch(`https://drive.google.com/uc?id=${id}&authuser=0&export=download`, {
        method: 'post',
        headers: {
            'accept-encoding': 'gzip, deflate, br',
            'content-length': 0,
            'Content-Type': 'application/x-www-form-urlencoded;charset=UTF-8',
            'origin': 'https://drive.google.com',
            'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/65.0.3325.181 Safari/537.36',
            'x-client-data': 'CKG1yQEIkbbJAQiitskBCMS2yQEIqZ3KAQioo8oBGLeYygE=',
            'x-drive-first-party': 'DriveWebUi',
            'x-json-requested': 'true'
        }
    })
    let {
        fileName,
        sizeBytes,
        downloadUrl
    } = JSON.parse((await res.text()).slice(4))
    if (!downloadUrl) throw 'Link Download Limit!'
    let data = await fetch(downloadUrl)
    if (data.status !== 200) throw data.statusText
    return {
        downloadUrl,
        fileName,
        mimetype: data.headers.get('content-type')
    }
}


export async function toAudio(buffer) {
    var filename = getRandom("mp4")
    var out = getRandom("mp3")
    await simpan(".cache/" + filename, buffer)
    var outname = cp.execSync(`ffmpeg -i ${".cache/"+filename} ${".cache/"+out}`)
    return baca(".cache/" + out)
}
export async function toImage(buffer) {
    var filename = getRandom("webp")
    var out = getRandom("png")
    await simpan(".cache/" + filename, buffer)
    var outname = cp.execSync(`ffmpeg -i ${".cache/"+filename} ${".cache/"+out}`)
    return baca(".cache/" + out)
}
export function getRandom(ext) {
    ext = ext || ""
    return `${Math.floor(Math.random() * 100000)}.${ext}`
}

function Audio() {
    this.ingfo = "apa coba";
}

Audio.prototype.bass = function(path, length) {
    return this.sox(path, null, `bass ${length}`)
}
Audio.prototype.treble = function(path, length) {
    return this.sox(path, null, `treble ${length}`)
}
Audio.prototype.fade = function(path, length) {
    return this.sox(path, null, `fade ${length.split("").join(" ")}`)
}
Audio.prototype.repeat = function(path, length) {
    return this.sox(path, null, `repeat ${length}`)
}
Audio.prototype.volume = function(path, length) {
    return this.sox(path, null, `gain ${length}`)
}
Audio.prototype.reverb = function(path) {
    return this.sox(path, null, "reverb 100 100 100 100 0 2")
}
Audio.prototype.slow = function(path) {
    return this.sox(path, null, "speed 0.85")
}
Audio.prototype.fast = function(path) {
    return this.sox(path, null, "speed 1.25")
}
Audio.prototype.speed = function(path, length) {
    return this.sox(path, null, "speed " + length)
}
Audio.prototype.reverse = function(path) {
    return this.sox(path, null, "reverse")
}
Audio.prototype.vibra = function(path, length, out) {
    return this.ffmpeg(path, `-filter_complex "vibrato=f=${length}"`, out)
}

Audio.prototype.cut = function(path, ar, out) {
    path = this.toPath(path)
    let outname = this.randomFilename()
    let ff = cp.execSync(`ffmpeg -ss ${ar[0]} -i ${path} -t ${ar[1]} -c copy ${outname}`).toString()
    if (ff.length == 0) return fs.readFileSync(outname)
}

Audio.prototype.robot = function(path) {
    return this.ffmpeg(path, `-filter_complex "afftfilt=real='hypot(re,im)*sin(0)':imag='hypot(re,im)*cos(0)':win_size=512:overlap=0.75"`, arguments[2])
}

Audio.prototype.tempo = function(path, length, out) {
    return this.ffmpeg(path, `-filter:a "atempo=1.0,asetrate=${length}"`, out)
}

Audio.prototype.cool = function(path, delay = 2, out) {
    return this.ffmpeg(path, `-af "aecho=in_gain=0.5:out_gain=0.5:delays=2:decays=0.2"`)
}
Audio.prototype.list = ["bass", "tempo", "volume", "cut", "robot", "cool", "vibra", "reverb", "slow"]
Audio.prototype.create = function() {
    return new Promise(async res => {
        let [key, val] = [Object.keys(arguments[1]), Object.values(arguments[1])];
        let path = this.toPath(arguments[0]);
        let i = 0;
        let hm = [];
        while (i < key.length && val.length) {
            if (i == 0) hm.push(await this[key[i]](path, val[i]))
            if (i == 1) hm.push(await this[key[i]](hm[i - 1], val[i]))
            if (i == 2) hm.push(await this[key[i]](hm[i - 1], val[i]))
            if (i == 3) hm.push(await this(key[i])(hm[i - 1], val[i]))
            if (i == 4) hm.push(await this(key[i])(hm[i - 1], val[i]))
            i++
        }
        res(hm[hm.length - 1]);
    });
}

Audio.prototype.ffmpeg = function(filename, command, out) {
    filename = this.toPath(filename)
    var outname = out || this.randomFilename()
    var ff = cp.execSync(`ffmpeg -i ${filename} ${command} ${outname} -y`).toString()
    var file = fs.readFileSync(outname)
    fs.unlinkSync(outname)
    if (ff.length == 0) return file
}
Audio.prototype.sox = function(filename, out, command) {
    filename = this.toPath(filename)
    var outname = out || this.randomFilename()
    var ff = cp.execSync(`sox ${filename} ${outname} ${command}`).toString()
    var file = fs.readFileSync(outname)
    fs.unlinkSync(outname)
    if (ff.length == 0) return file
}

Audio.prototype.randomFilename = function() {
    return ".cache/" + Math.floor(Math.random() * 100 * 100) + ".mp3"
}

Audio.prototype.toPath = function() {
    let buff = arguments[0];
    if (!Buffer.isBuffer(buff)) {
        if (!fs.existsSync(buff)) throw this.makeError("no such file directory", "Error: ENOENT")
        return buff;
    }
    let file = this.randomFilename()
    fs.writeFileSync(file, buff)
    return file;
}

Audio.prototype.makeError = function(message, name) {
    let err = new Error;
    err.name = name;
    err.message = message;
    return err
}
export function toHHMMSS(sec_num) {
    var hours = Math.floor(sec_num / 3600);
    var minutes = Math.floor((sec_num - hours * 3600) / 60);
    var seconds = sec_num - hours * 3600 - minutes * 60;

    if (hours < 10) {
        hours = "0" + hours;
    }
    if (minutes < 10) {
        minutes = "0" + minutes;
    }
    if (seconds < 10) {
        seconds = "0" + seconds;
    }
    console.log(hours + ":" + minutes + ":" + seconds);
    return hours + ":" + minutes + ":" + seconds;
}
export async function imageToWebp(media) {
    const tmpFileOut = path.join(".cache", `${crypto.randomBytes(6).readUIntLE(0, 6).toString(36)}.webp`)
    const tmpFileIn = path.join(".cache", `${crypto.randomBytes(6).readUIntLE(0, 6).toString(36)}.jpg`)
    fs.writeFileSync(tmpFileIn, media)
    await new Promise((resolve, reject) => {
        ff(tmpFileIn)
            .on("error", reject)
            .on("end", () => resolve(true))
            .addOutputOptions([
                "-vcodec",
                "libwebp",
                "-vf",
                "scale='min(320,iw)':min'(320,ih)':force_original_aspect_ratio=decrease,fps=15, pad=320:320:-1:-1:color=white@0.0, split [a][b]; [a] palettegen=reserve_transparent=on:transparency_color=ffffff [p]; [b][p] paletteuse"
            ])
            .toFormat("webp")
            .save(tmpFileOut)
    })
    const buff = fs.readFileSync(tmpFileOut)
    fs.unlinkSync(tmpFileOut)
    fs.unlinkSync(tmpFileIn)
    return buff
}

export async function videoToWebp(media) {
    const tmpFileOut = path.join(".cache", `${crypto.randomBytes(6).readUIntLE(0, 6).toString(36)}.webp`)
    const tmpFileIn = path.join(".cache", `${crypto.randomBytes(6).readUIntLE(0, 6).toString(36)}.mp4`)
    fs.writeFileSync(tmpFileIn, media)
    await new Promise((resolve, reject) => {
        ff(tmpFileIn)
            .on("error", reject)
            .on("end", () => resolve(true))
            .addOutputOptions([
                "-vcodec",
                "libwebp",
                "-vf",
                "scale='min(320,iw)':min'(320,ih)':force_original_aspect_ratio=decrease,fps=15, pad=320:320:-1:-1:color=white@0.0, split [a][b]; [a] palettegen=reserve_transparent=on:transparency_color=ffffff [p]; [b][p] paletteuse",
                "-loop",
                "0",
                "-ss",
                "00:00:00",
                "-t",
                "00:00:05",
                "-preset",
                "default",
                "-an",
                "-vsync",
                "0"
            ])
            .toFormat("webp")
            .save(tmpFileOut)
    })

    const buff = fs.readFileSync(tmpFileOut)
    fs.unlinkSync(tmpFileOut)
    fs.unlinkSync(tmpFileIn)
    return buff
}

export async function savingMedia(media) {
    const tmpFileOut = path.join(".cache", `${crypto.randomBytes(6).readUIntLE(0, 6).toString(36)}.webp`)
    const tmpFileIn = path.join(".cache", `${crypto.randomBytes(6).readUIntLE(0, 6).toString(36)}.mp4`)
    fs.writeFileSync(tmpFileOut, media)
    const buff = fs.readFileSync(tmpFileOut)
    fs.unlinkSync(tmpFileOut)
    return buff
}

export async function writeExifImg(media, metadata) {
    let wMedia = await imageToWebp(media)
    const tmpFileIn = path.join(".cache", `${crypto.randomBytes(6).readUIntLE(0, 6).toString(36)}.webp`)
    const tmpFileOut = path.join(".cache", `${crypto.randomBytes(6).readUIntLE(0, 6).toString(36)}.webp`)
    fs.writeFileSync(tmpFileIn, wMedia)

    if (metadata.packname || metadata.author) {
        const img = new webp.Image()
        const json = {
            "sticker-pack-id": `https://github.com/Rifza123`,
            "sticker-pack-name": metadata.packname,
            "sticker-pack-publisher": metadata.author,
            "emojis": metadata.categories ? metadata.categories : [""]
        }
        const exifAttr = Buffer.from([0x49, 0x49, 0x2A, 0x00, 0x08, 0x00, 0x00, 0x00, 0x01, 0x00, 0x41, 0x57, 0x07, 0x00, 0x00, 0x00, 0x00, 0x00, 0x16, 0x00, 0x00, 0x00])
        const jsonBuff = Buffer.from(JSON.stringify(json), "utf-8")
        const exif = Buffer.concat([exifAttr, jsonBuff])
        exif.writeUIntLE(jsonBuff.length, 14, 4)
        await img.load(tmpFileIn)
        fs.unlinkSync(tmpFileIn)
        img.exif = exif
        await img.save(tmpFileOut)
        return tmpFileOut
    }
}

export async function writeExifVid(media, metadata) {
    let wMedia = await videoToWebp(media)
    const tmpFileIn = path.join(".cache", `${crypto.randomBytes(6).readUIntLE(0, 6).toString(36)}.webp`)
    const tmpFileOut = path.join(".cache", `${crypto.randomBytes(6).readUIntLE(0, 6).toString(36)}.webp`)
    fs.writeFileSync(tmpFileIn, wMedia)

    if (metadata.packname || metadata.author) {
        const img = new webp.Image()
        const json = {
            "sticker-pack-id": `https://github.com/Rifza123`,
            "sticker-pack-name": metadata.packname,
            "sticker-pack-publisher": metadata.author,
            "emojis": metadata.categories ? metadata.categories : [""]
        }
        const exifAttr = Buffer.from([0x49, 0x49, 0x2A, 0x00, 0x08, 0x00, 0x00, 0x00, 0x01, 0x00, 0x41, 0x57, 0x07, 0x00, 0x00, 0x00, 0x00, 0x00, 0x16, 0x00, 0x00, 0x00])
        const jsonBuff = Buffer.from(JSON.stringify(json), "utf-8")
        const exif = Buffer.concat([exifAttr, jsonBuff])
        exif.writeUIntLE(jsonBuff.length, 14, 4)
        await img.load(tmpFileIn)
        fs.unlinkSync(tmpFileIn)
        img.exif = exif
        await img.save(tmpFileOut)
        return tmpFileOut
    }
}

export async function writeExifStc(media, metadata) {
    let wMedia = await savingMedia(media)
    const tmpFileIn = path.join(".cache", `${crypto.randomBytes(6).readUIntLE(0, 6).toString(36)}.webp`)
    const tmpFileOut = path.join(".cache", `${crypto.randomBytes(6).readUIntLE(0, 6).toString(36)}.webp`)
    fs.writeFileSync(tmpFileIn, wMedia)
    if (metadata.packname || metadata.author) {
        const img = new webp.Image()
        const json = {
            "sticker-pack-id": `https://github.com/Rifza123`,
            "sticker-pack-name": metadata.packname,
            "sticker-pack-publisher": metadata.author,
            "emojis": metadata.categories ? metadata.categories : [""]
        }
        const exifAttr = Buffer.from([0x49, 0x49, 0x2A, 0x00, 0x08, 0x00, 0x00, 0x00, 0x01, 0x00, 0x41, 0x57, 0x07, 0x00, 0x00, 0x00, 0x00, 0x00, 0x16, 0x00, 0x00, 0x00])
        const jsonBuff = Buffer.from(JSON.stringify(json), "utf-8")
        const exif = Buffer.concat([exifAttr, jsonBuff])
        exif.writeUIntLE(jsonBuff.length, 14, 4)
        await img.load(tmpFileIn)
        fs.unlinkSync(tmpFileIn)
        img.exif = exif
        await img.save(tmpFileOut)
        return tmpFileOut
    }
}

export async function writeExif(media, metadata) {
    let wMedia = /webp/.test(media.mimetype) ? media.data : /image/.test(media.mimetype) ? await imageToWebp(media.data) : /video/.test(media.mimetype) ? await videoToWebp(media.data) : ""
    const tmpFileIn = path.join(".cache", `${crypto.randomBytes(6).readUIntLE(0, 6).toString(36)}.webp`)
    const tmpFileOut = path.join(".cache", `${crypto.randomBytes(6).readUIntLE(0, 6).toString(36)}.webp`)
    fs.writeFileSync(tmpFileIn, wMedia)

    if (metadata.packname || metadata.author) {
        const img = new webp.Image()
        const json = {
            "sticker-pack-id": `https://github.com/Rifza123`,
            "sticker-pack-name": metadata.packname,
            "sticker-pack-publisher": metadata.author,
            "emojis": metadata.categories ? metadata.categories : [""]
        }
        const exifAttr = Buffer.from([0x49, 0x49, 0x2A, 0x00, 0x08, 0x00, 0x00, 0x00, 0x01, 0x00, 0x41, 0x57, 0x07, 0x00, 0x00, 0x00, 0x00, 0x00, 0x16, 0x00, 0x00, 0x00])
        const jsonBuff = Buffer.from(JSON.stringify(json), "utf-8")
        const exif = Buffer.concat([exifAttr, jsonBuff])
        exif.writeUIntLE(jsonBuff.length, 14, 4)
        await img.load(tmpFileIn)
        fs.unlinkSync(tmpFileIn)
        img.exif = exif
        await img.save(tmpFileOut)
        return tmpFileOut
    }
}
export function random(value) {
    if (!value) return new Error("empty value")
    return value[Math.floor(Math.random() * value.length)]
}


export function bindSock(sock) {
    Object.defineProperties(sock, {
        sendText: {
            async value(jid, text, options) {
                return sock.sendMessage(jid, {
                    text,
                    ...options
                }, {
                    ...options
                })
            }
        },
        reply: {
            value(jid, text, quoted, options) {
                return sock.sendMessage(jid, {
                    text,
                    ...options
                }, {
                    quoted,
                    ...options
                })
            }
        },
        sendMessage2: {
            async value(jid, content, options = {}) {
                const userJid = sock.authState.creds.me.id;
                const fullMsg = await baileys.generateWAMessage(jid, content, {
                    userJid,
                    upload: sock.waUploadToServer,
                    ...options
                });
                const isDeleteMsg = 'delete' in content && !!content.delete;
                const additionalAttributes = {};
                // required for delete
                if (isDeleteMsg) {
                    // if the chat is a group, and I am not the author, then delete the message as an admin
                    if (baileys.isJidGroup((_a = content.delete) === null || _a === void 0 ? void 0 : _a.remoteJid) && !((_b = content.delete) === null || _b === void 0 ? void 0 : _b.fromMe)) {
                        additionalAttributes.edit = '8';
                    } else {
                        additionalAttributes.edit = '7';
                    }
                }
                await sock.relayMessage(jid, fullMsg.message, {
                    messageId: fullMsg.key.id,
                    participant: options.participant ? {
                        jid: options.participant
                    } : null,
                    cachedGroupMetadata: options.cachedGroupMetadata,
                    additionalAttributes
                });
                return fullMsg;
            }
        },
        getFile: {
            async value(media) {
                let data = Buffer.isBuffer(media) ? media : isUrl(media) ? await (await fetch(media)).buffer() : fs.existsSync(media) ? fs.readFileSync(media) : /^data:.*?\/.*?;base64,/i.test(media) ? Buffer.from(media.split(",")[1]) : null
                if (!data) return new Error("Result is not a buffer")
                let type = await fileType.fileTypeFromBuffer(data) || {
                    mime: "application/octet-stream",
                    ext: ".bin"
                }
                return {
                    data,
                    ...type
                }
            }
        },
        sendFile: {
            async value(jid, media, options = {}) {
                let file = await sock.getFile(media)
                let mime = file.ext,
                    type
                if (mime == "mp3") {
                    type = "audio"
                    options.mimetype = "audio/mpeg"
                    options.ptt = options.ptt || false
                } else if (mime == "jpg" || mime == "jpeg" || mime == "png") type = "image"
                else if (mime == "webp") type = "sticker"
                else if (mime == "mp4") type = "video"
                else type = "document"
                return sock.sendMessage(jid, {
                    [type]: file.data,
                    ...options
                }, {
                    ...options
                })
            }
        },
        fetchData: {
            async value(url, options = {}) {
                try {
                    var {
                        data
                    } = await axios({
                        url,
                        ...options
                    })
                    return data
                } catch (e) {
                    return e.response
                }
            }
        },
        fetchBuffer: {
            async value(url) {
                try {
                    var req = await fetch(url)
                    return await req.buffer()
                } catch (e) {
                    return e
                }
            }
        },
    })
}


export default Message;
export const audio = new Audio()
export const format = new Formarter()
export const anonfiles = new anonFiles()



