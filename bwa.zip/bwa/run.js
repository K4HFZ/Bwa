import baileys from "@adiwajshing/baileys";
import Jimp from "jimp";
import chalk from "chalk";
import P from "pino";
import index from './index.js';

global.owner = ["6283137014833@s.whatsapp.net"];
global.functions = await import("./functions.js");
global.prefix = ".";
global.self = true;
global.welcome = false;

const main = async (auth, own) => {
var fileAuth = await baileys.useMultiFileAuthState(auth);
var sock = baileys.default({
auth: fileAuth.state,
printQRInTerminal: true,
markOnlineOnConnect: false,
logger: P({
level: "silent"
})
});
console.log(chalk.cyan("Connect to WA Web"));
functions.bindSock(sock);
sock.ev.on("creds.update", fileAuth.saveCreds);
sock.ev.on("sockection.update", update => {
if (update.sockection == "close") {
var code = update.lastDisconnect?.error?.output?.statusCode;
console.log(update.lastDisconnect?.error);
if (code != 401) {
main(".session", owner);
}
}
});
    
sock.ev.on("messages.upsert", async (message) => {
if (!message.messages[0]) return;
let msg = message.messages[0];
var pic = await sock.fetchBuffer("https://i.ibb.co/hmFgJtM/pngwing-com-2.png");
index(sock, msg);
var ftxt = {
key: {
fromMe: false,
participant: "0@s.whatsapp.net",
...(msg.key.remoteJid ? {
remoteJid: "status@broadcast"
} : {})
},
message: {
"imageMessage": {
"jpegThumbnail": await functions.reSize(pic ? pic : thumbnail, 300, 300),
"caption": "Group Announce"
}
}
}
})
}
main(".session", owner)